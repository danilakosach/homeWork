def num_translate ():
    try:
        numbers = {'one': 'один', 'two': 'два', 'three': 'три', 'four': 'четыре', 'five': 'пять', 'six': 'шесть',
               'seven': 'семь', 'eight': 'восемь', 'nine': 'девять', 'ten': 'десять'}
        for i in numbers:
            j = input('Enter the number:')
            print(numbers[j])
    except:
        print('None')


num_translate()