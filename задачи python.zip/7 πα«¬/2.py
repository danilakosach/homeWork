import os
dir_name = ('my_project/mainapp/templates','my_project/authapp/templates')
directories = ('settings','mainapp','authapp')
file_settings = ('my_project/settings/__init__.py','my_project/settings/dev.py', 'my_project/settings/prod.py'
                 ,'my_project/mainapp/__init__.py','my_project/mainapp/models.py', 'my_project/mainapp/views.py'
                ,'my_project/mainapp/templates/base.html','my_project/mainapp/templates/index.html'
                ,'my_project/authapp/templates/base.html','my_project/authapp/templates/index.html'
                ,'my_project/authapp/__init__.py','my_project/authapp/models.py', 'my_project/authapp/views.py')
for i in directories:
    dir_path = os.path.join('my_project', i)
    if not os.path.exists(dir_path):
       os.makedirs(dir_path)
for templates in dir_name:
    if not os.path.exists(templates):
        os.mkdir(templates)
for settings in file_settings:
    open(settings,'w')