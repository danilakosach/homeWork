def odd_numbers(n):
    a = -1
    for i in range(0,n):
        a += 2
        yield a

odd_tu_15 = odd_numbers(15)
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
print(next(odd_tu_15))
