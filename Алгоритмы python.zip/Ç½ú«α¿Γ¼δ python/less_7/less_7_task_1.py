"""1. Отсортируйте по убыванию методом пузырька одномерный целочисленный массив,
 заданный случайными числами на промежутке [-100; 100).
 Выведите на экран исходный и отсортированный массивы."""

import random

size = 10
array = [random.randint(-100, 99) for i in range(size)]
print(array)

for i in range(9):
    for j in range(9 - i):
        if array[j] > array[j + 1]:
            array[j], array[j + 1] = array[j + 1], array[j]
print(array)
