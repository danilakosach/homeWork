list_1 = [5,18,33,2,9,65,358,4,66,59,89,79,15,36]
list_2 =[]
for i in range(len(list_1)-1):
    if list_1[i] < list_1[i + 1]:
        list_2.append(list_1[i + 1])

print(list_2)