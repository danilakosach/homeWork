import os
path = ('settings','mainapp','adminapp','authapp')
for i in path:
    dir_path = os.path.join('my_project', i)
    if not os.path.exists(dir_path):
       os.makedirs(dir_path)
