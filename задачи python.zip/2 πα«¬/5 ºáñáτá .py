my_text = [22.01, 86.12, 65.5, 98.63, 896.48, 63.56, 563.21, 325.24, 61.66]

my_text_2 = []

for i, j in enumerate(my_text):
  if '.' in str(j):
    my_text_2.append('{0} руб {1:02d} коп'.format(int(str(my_text[i]).split('.')[0]),
                                                  int(str(my_text[i]).split('.')[1])))
  else:
    my_text_2.append('{0} руб 00 коп'.format(int(str(my_text[i]).split('.')[0])))
print(id(my_text))
print(', '.join(my_text_2))