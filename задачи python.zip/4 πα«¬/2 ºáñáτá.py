import requests
from requests import  get, utils
from datetime import date

def currency_rates(value_code):
    char_code_list = []
    nominal_list = []
    value_list = []
    rates_dict = {}

    CB_RATES_URL = 'http://www.cbr.ru/scripts/XML_daily.asp'
    response = requests.get(CB_RATES_URL)
    encodings = utils.get_encoding_from_headers(response.headers)
    response_str = response.content.decode(encoding=encodings)

    day, month, year = map(int, response_str.split('<ValCurs Date="')[1].split('"name=')[0].split('.'))

    for item in response_str.split('<CharCode>')[1:]:
        char_code_list.append(item[:3])

    for item in response_str.split('<Nominal>')[1:]:
        nominal_list.append(float(item.split('</Nominal>')[0]))
    for item in response_str.split('<Value>')[1:]:
        value_list.append(float(item.split('</Value>')[0].replace(',', '.')))
    for code,nominal,value in zip(char_code_list, nominal_list, value_list):
        rates_dict[code]= [nominal,value]

    return 'Курс валюты {} составляет: {} рублей на дату {}'\
        .format(value_code,rates_dict[value_code][1]/ rates_dict[value_code][0],date(year, month, day))

currency_rates('USD')
