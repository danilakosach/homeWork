nouns = ["автомобиль", "лес", "огонь", "город", "дом"]
adverbs = ["сегодня", "вчера", "завтра", "позавчера", "ночью"]
adjectives = ["веселый", "яркий", "зеленый", "утопичный", "мягкий"]

import random

def run_jokes(j,input_lists, repeat_flg = False):
    rund_list_nouns = []
    rund_list_adverbs = []
    rund_list_adjectives = []
    rand_lists = [rund_list_nouns , rund_list_adverbs , rund_list_adjectives]

    if repeat_flg:
        for i in range(j):
            rund_list_nouns.append(random.choice(nouns))
            rund_list_adverbs.append(random.choice(adverbs))
            rund_list_adjectives.append(random.choice(adjectives))
    else:
        for i in range(3):
            tmp_dict={}
            while len(tmp_dict) < j:
                tmp_dict[random.choice(input_lists[i])] = ''
            rand_lists[i].extend(tmp_dict.keys())
    return list(map(' '.join, list(map(list,zip(rand_list_nouns, rund_list_adverbs,rund_list_adjectives  )))))

get_jokes(2, [nouns,adverbs,adjectives], True)