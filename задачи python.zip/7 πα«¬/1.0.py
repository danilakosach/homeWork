import os

dir_path = os.path.join('my_project', 'settings')
dir_path2 = os.path.join('my_project', 'mainapp')
dir_path3= os.path.join('my_project', 'adminapp')
dir_path4 = os.path.join('my_project', 'authapp')
if not os.path.exists(dir_path):
   os.makedirs(dir_path)
   os.makedirs(dir_path2)
   os.makedirs(dir_path3)
   os.makedirs(dir_path4)

