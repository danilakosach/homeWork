def thesaurus(*args):
    res_dict = {}
    for i in sorted(args):
        if i.split(' ')[0][0] in res_dict:
            res_dict[i.split(' ')[0][0]].append(i)
        else:
            res_dict[i.split(' ')[0][0]] = []
            res_dict[i.split(' ')[0][0]].append(i)
    return dict(sorted(res_dict.items()))

thesaurus("Андрей Петров", "Алексей Попов", "Ваня Смирнов", "Виктор Старовойтов", "Евгений Ловцов")