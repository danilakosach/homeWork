class Road:
    def __init__(self, _length, _width, volume):
        self._length = _length
        self._width = _width
        self.volume = volume

    def massa(self):
        return self._length * self._width * self.volume * 1


class MassCount(Road):
    def __init__(self, _length, _width, volume):
        super().__init__(_length, _width, volume )
        self.volume = volume

r = MassCount(1000, 8, 123)
print(r.massa())
