with open('nginx_logs.txt', 'r', encoding='utf-8') as file_1:
   for line in file_1:
       ip = line.split(' ')
       print(ip[0],',',ip[5].replace('"',''),',',ip[6])