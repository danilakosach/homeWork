file_1 = open('users.txt', 'r', encoding='utf-8')
file_2 = open('hobby.txt', 'r', encoding='utf-8')
with open('dictionary.txt', 'w', encoding='utf-8') as f:
    users_hobby = {}
    for i in file_1:
        users_hobby ={i}
        y = file_2.readline()
        users_hobby = {i:y}
        print(users_hobby)
        f.write(str({i:y}))