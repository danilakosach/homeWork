text = ['в', '5', 'часов', '17', 'минут', 'температура','воздуха', 'была', '+5', 'градусов']

print('id исход: {}'.format(id(text)))

lists = []
numbers = 0
for i, j in enumerate (text):
  if ((j.startswith('+') or j.startswith('-')) and j[1:].isdigit()):
    lists.append(i + numbers)
    lists.append(i + numbers +2)
    text[i] = '{0}{1:02d}'.format(j[0],int(j[1:]))
    numbers += 2
  if j.isdigit():
    lists.append(i + numbers)
    lists.append(i + numbers +2)
    text[i] = '{:02d}'.format(int(j))
    numbers += 2
for i in lists:
  text.insert(i,'"')

print('id нового : {}'.format(id(text)))

text = list(' '.join(text))

char_index = 0
for i, char in enumerate(text):
  if char == '"' and char_index % 2 == 0:
    text.pop(i + 1)
    char_index += 1
  elif char == '"' and char_index % 2 == 1:
    text.pop(i - 1)
    char_index += 1
print ('Результирующая строка: {}'.format(''.join(text)))