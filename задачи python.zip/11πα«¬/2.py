class DivisionBy_zero:
    def __init__(self, divider, denominator):
        self.divider = divider
        self.denominator = denominator

    @staticmethod
    def divide_by_null(divider, denominator):
        try:
            return (divider / denominator)
        except:
            return (f"Деление на ноль запрещено!")


div = DivisionBy_zero(10, 100)
print(DivisionBy_zero.divide_by_null(8, 0))
print(DivisionBy_zero.divide_by_null(10, 0.1))
print(div.divide_by_null(15, 0))
print(div.divide_by_null(15, 3))